using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Normal text element
/// </summary>
public class PUI_Text : PUI_Component {
	public PUI_Text(Config config) : base(config) { }
}