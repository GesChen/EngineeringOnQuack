public partial class Primitive : Type
{
	public partial class String : Primitive
	{
		public string Value;

		public String(string value)
		{
			Value = value;
		}
	}
}