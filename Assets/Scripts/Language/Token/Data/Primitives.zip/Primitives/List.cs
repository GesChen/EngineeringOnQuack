using System.Collections.Generic;

public partial class Primitive : Type
{
	public partial class List : Primitive
	{
		public List<Data> Values;

		public List(List<Data> values)
		{
			Values = values;
		}
	}
}