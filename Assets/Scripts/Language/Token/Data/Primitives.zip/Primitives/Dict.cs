using System.Collections.Generic;

public partial class Primitive : Type
{
	public partial class Dict : Primitive
	{
		public Dictionary<Data, Data> Dictionary;

		public Dict()
		{
			Dictionary = new();
		}

		public Dict(Dictionary<Data, Data> dictionary)
		{
			Dictionary = dictionary;
		}
	}
}