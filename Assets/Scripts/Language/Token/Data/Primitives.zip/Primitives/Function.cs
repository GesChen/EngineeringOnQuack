using System.Collections;
using System.Collections.Generic;

public partial class Primitive : Type
{
	public partial class Function : Primitive
	{
		public Section Section;

		public Function(Section section) : base("Function")
		{
			Section = section;
		}

		public bool IsInternalMethod = false;
		public delegate Data InternalMethodDeleagte(List<Data> args);
		public InternalMethodDeleagte InternalMethod;
		
		public Function (InternalMethodDeleagte internalMethod) : base("InternalFunction")
		{
			IsInternalMethod = true;
			InternalMethod = internalMethod;
		}

		
	}
}