public partial class Primitive : Type
{
	public partial class Number : Primitive
	{
		public double Value;

		public Number(double value)
		{
			Value = value;
		}
	}
}
