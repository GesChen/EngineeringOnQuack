public partial class Primitive : Type
{
	public partial class Error : Primitive
	{
		public string Text;

		public Error(string text)
		{
			Text = text;
		}
	}
}
