public partial class Primitive : Type {
	public partial class Bool : Primitive {
		public bool Value;

		public Bool(bool value) : base("Bool") {
			Value = value;
		}
	}
}