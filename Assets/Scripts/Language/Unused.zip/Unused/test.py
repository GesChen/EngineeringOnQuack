class a:
    def __init__(self, x, y):
        self.x = x
        self.y = y

foo = 5

print(foo.x)

foo.z = 100

print(foo.z)